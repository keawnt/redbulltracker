# CanCount — Claude Design Mockup Prompt

> Paste everything below into Claude Design.

---

Design high-fidelity iPhone mockups for **CanCount** — a Red Bull consumption tracker that treats energy drink logging with the same obsessive stat-craft as Flighty treats flights. Scan a can, it logs the exact flavor and size, tracks your weekly totals and caffeine, and ranks you against friends. The joke is that it's completely unserious subject matter executed with completely serious design.

Create **5 iPhone screens** (iPhone 16 Pro frame, 393×852pt): Home, Scanner Success, Stats, Leaderboard, and Weekly Recap Share Card.

## Aesthetic Direction

**GO Club (iOS) meets Apple's Liquid Glass, in Red Bull's colors.**

- **Canvas**: near-black `#0A0A0C`. Dark mode only — this is a nighttime-energy app.
- **Accents**: energy yellow `#FFC906` as the single hero accent (used sparingly, so it screams). Deep racing blue `#2E5FDF` as secondary. Streak/record moments in Red Bull red `#DB0A40`. Silver metallic `#C8CDD4` for glass edges and can-adjacent details.
- **Liquid Glass surfaces**: cards, tab bar, buttons, and stat pills are translucent frosted glass — soft refraction, 1px luminous edge highlight, content behind them glowing through. The tab bar is a floating glass capsule, not an edge-to-edge bar.
- **Typography**: SF Pro Rounded. Giant heavy display numerals are the signature — the weekly can count should be ~120pt, dominating the Home screen like GO Club's step counts. Labels small, uppercase, tracked-out, in 50% white.
- **The can is the mascot**: a photorealistic Red Bull can (silver-blue original, or a flavor Edition with its colored can) appears as a floating 3D hero object with a soft yellow ambient glow beneath it. It should feel like a collectible, not a product shot.
- **Personality in the copy**: microcopy is dry and confident. Examples to use in the mockups: "3 today. Your heart rate agrees." / "New PR. Please drink water." / "Zero cans. Suspicious."
- **Rounded everything**: 28pt card radii, pill buttons, squircle avatars.

## Screen 1 — Home ("Today")

- Top: small greeting ("Thursday. You know what to do.") + streak flame pill "🔥 12"
- Hero zone: giant numeral **14** with label "CANS THIS WEEK", the floating can beside/behind it with glow and subtle drop shadow
- Row of three glass stat pills: "3 today" / "342mg caffeine" / "PR pace ↑"
- "Recent sips" — three compact glass cards: flavor color chip, name ("Blue Edition"), size ("12oz"), time ("2:41 PM")
- Bottom: floating glass tab capsule (Home, Stats, Leaderboard, Profile) with a large prominent yellow glass **scan button** breaking out of its center

## Screen 2 — Scanner Success

- Darkened camera viewfinder background with a glass viewfinder frame, yellow corner brackets
- Center: the just-scanned can (Purple Edition) large and celebratory, ring of light behind it
- Glass result card slid up from bottom: "Red Bull Purple Edition · 12oz · 114mg caffeine · 39g sugar" with a full-width yellow glass CONFIRM button and a subtle size-override segmented control (8.4 / 12 / 16 / 20oz)
- Small confetti particles (yellow/blue/silver) mid-burst around the can

## Screen 3 — Stats

- Week selector: horizontal glass segmented control ("This week" active)
- Bar chart: cans per day Mon–Sun, bars colored by dominant flavor of each day, today's bar glowing yellow, big Y-axis-free minimal styling
- Flavor breakdown: donut chart with flavor colors + a "flavor personality" glass card: "TROPICAL LOYALIST — 61% Yellow Edition. Committed."
- Lifetime footer strip: "217 cans · 76L · 24,650mg caffeine (= 274 espressos)"

## Screen 4 — Leaderboard

- Header: crew name "THE PIT CREW" + invite icon
- Podium: top 3 avatars on glass pedestals — gold glow center (1st, "Keawn — 14"), silver left, bronze right, playful crown on #1
- Ranked list below: rows with squircle avatar, name, weekly count, delta arrow ("↑2") — 4th through 7th place visible
- Footer note: "Resets Sunday midnight. Lindsay is 2 cans behind you."

## Screen 5 — Weekly Recap Share Card

- A shareable boarding-pass-style card (Flighty passport energy) on the dark canvas: "WEEK 27 RECAP" header, giant "14 CANS", stat rows (top flavor, biggest day, caffeine total, streak), a barcode graphic as a design flourish at the bottom, CanCount wordmark
- Framed as if in a share sheet moment

## What to avoid

- No white/light backgrounds anywhere
- No generic fitness-app gradients (purple-to-pink etc.) — the palette is strictly black/yellow/blue/red/silver
- No dense dashboards — every screen has ONE hero element and generous negative space
- Don't render the official Red Bull logo lockup; suggest the brand through can shapes and colors instead
