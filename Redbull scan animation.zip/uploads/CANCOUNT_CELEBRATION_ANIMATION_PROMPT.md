# CanCount — "Can Drop" Celebration Animation Prompt

> Paste everything below into Claude Design.

---

Build an **animated motion prototype** (iPhone 16 Pro frame, 393×852) of CanCount's post-scan celebration — the moment after a user confirms a scanned Red Bull. This is our Duolingo moment: a full-screen takeover where the can becomes a giant celebratory mascot, the flavor's color floods the screen, and the count ticks up. It should loop or replay on tap so I can study the timing.

The prototype starts on a simplified Home screen (dark `#0A0A0C` canvas, giant "13 CANS THIS WEEK" numeral, glass tab capsule at bottom, yellow scan button). Tapping the scan button skips straight to the celebration (don't build the camera — fake a 0.3s "scanning" flash).

## The scanned drink for this prototype

**Red Bull Purple Edition (Açaí), 12oz** — can is deep violet with silver, flavor accent color `#7B2FBE`.

## Motion Choreography — exact timeline

Duolingo DNA: sequential (never simultaneous), overshooting springs, full-screen color commitment, one hero element at a time. Total sequence ~3.2s then settles.

**Phase 1 — Color flood (0.0s → 0.4s)**
- From the scan button's position, a circle of the flavor color `#7B2FBE` expands radially until it fills the entire screen (ease-out, like Duolingo's screen-color takeovers). The dark Home UI is swallowed beneath it.
- Subtle radial gradient once filled: brighter violet center, darker violet edges — stage-lighting for the can.

**Phase 2 — The can slams in (0.4s → 1.0s)**
- The Purple Edition can drops from above the top edge to dead center, LARGE (roughly 55% of screen height), with a heavy spring: overshoots downward ~40px, compresses/squashes ~6% vertically on "impact", rebounds to rest with 2 diminishing bounces.
- On impact: a shockwave ring ripples outward from the can's base, screen does a 2px shake, and a burst of carbonation bubbles rises from behind the can.
- The can idles with a slow ±3° tilt sway and a soft floating bob, silver spec highlight slowly sweeping across it.

**Phase 3 — Type slams in (1.0s → 1.6s)**
- "**CAN #14**" slams in above the can — SF Pro Rounded, ultra-heavy, white, ~64pt — scaling from 140% down to 100% with overshoot.
- Beneath the can, secondary line fades up: "Purple Edition · 12oz · 114mg" in small tracked-out caps, 70% white.
- A dry one-liner fades in below that: *"Four today. Your heart rate agrees."*

**Phase 4 — Counter tick + streak (1.6s → 2.4s)**
- A glass pill drops in below the copy: the weekly counter rolling odometer-style from **13 → 14** (digits physically roll upward), followed by a streak flame pill "🔥 12" popping in with a scale bounce.
- Confetti burst at the moment the odometer lands on 14: yellow `#FFC906`, silver, and violet particles — mix of tiny rectangles and can-shaped silhouettes — erupting from behind the can, falling with physics (gravity, drift, rotation).

**Phase 5 — Settle (2.4s → 3.2s)**
- Confetti finishes falling. A frosted-glass "**KEEP IT COLD**" continue button slides up from the bottom with a spring.
- Everything idles: can swaying, bubbles occasionally rising, flame flickering.
- Tapping continue reverses the color flood (circle contracts back into the scan button) revealing Home, where the hero numeral now reads 14 and does one small congratulatory pulse.

## Feel rules

- Springs everywhere: nothing uses linear or plain ease-in-out except the color flood. Target `spring(response 0.4–0.5, damping 0.6–0.7)` energy — visible overshoot on every entrance.
- Stagger, don't stack: each element waits for the previous one's overshoot to settle before entering.
- The color flood commits 100% — no dark UI peeking through during the celebration.
- 60fps smoothness matters more than particle count; cap confetti at ~80 particles.
- Add a replay button (small, corner, glass) so I can loop the sequence.

## Avoid

- No official Red Bull logo lockup — suggest the can through shape, violet/silver coloring, and a generic bull-silhouette-free design
- No sound needed
- No light backgrounds; even the flood color stays deep and saturated
